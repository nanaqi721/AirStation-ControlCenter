CREATE TABLE SysAdmin (
    LoginId      INTEGER      DEFAULT (10000) 
                              PRIMARY KEY AUTOINCREMENT,
    LoginName    VARCHAR (20) NOT NULL,
    LoginPwd     VARCHAR (20) NOT NULL,
    LogAlarm     BOOLEAN      NOT NULL,
    HistoryLog     BOOLEAN      NOT NULL,
    ActualTrend  BOOLEAN      NOT NULL,
    HistoryTrend BOOLEAN      NOT NULL,
    ParamSet     BOOLEAN      NOT NULL,
    Report       BOOLEAN      NOT NULL,
    UserManage   BOOLEAN      NOT NULL
);

CREATE TABLE SysLog (
    Id         INTEGER      DEFAULT (1) 
                            PRIMARY KEY AUTOINCREMENT,
    InsertTime VARCHAR (50) NOT NULL,
    Note       VARCHAR (20) NOT NULL,
    LogType    int NOT NULL,
    Operator   VARCHAR (20) NOT NULL,
    VarName    VARCHAR (20),
    AlarmSet   VARCHAR (20),
    AlarmValue VARCHAR (20),
    AlarmType  Boolean
);
